package sustech.cs102a.lab10;

import java.util.Scanner;

public class Lab10E1 {
    public static void main(String[] args) {
        System.out.print("Your budget: ");
        Scanner input = new Scanner(System.in);
        int buget = input.nextInt();

        boolean isSufficient = false;
        for(PhoneModel phone: PhoneModel.values()){
             if (phone.getPrice()<=buget){
                 System.out.printf("%-12sprice:%5d\n", phone.name(), phone.getPrice());
                 isSufficient = true;
             }
        }
        if(!isSufficient){
            System.out.println("You do not have sufficient money");
        }

    }
}
