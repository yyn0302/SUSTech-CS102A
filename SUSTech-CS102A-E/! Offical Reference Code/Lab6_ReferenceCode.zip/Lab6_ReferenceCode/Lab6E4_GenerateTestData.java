import java.util.Random;

public class Lab6E4_GenerateTestData {

	// the max value in matrix is maxDimension-1
	// the max dimension of inner matrix is maxDimension -1
	static final int MAXDIMENSION = 10;

	public static void main(String[] args) {
		int T = 3;
		generateData(T);
	}

	// this method will generate T matrices
	// the last product of this matrices is T*T
	public static void generateData(int T) {
		System.out.println(T);
		Random r = new Random();
		// a is row and b is column
		// each time shift b to a to make it a valid product
		int a, b = T;
		for (int i = 0; i < T; i++) {
			a = b;
			do {
				b = i == T - 1 ? T : r.nextInt(MAXDIMENSION);
			} while (b == 0);
			System.out.printf("%d %d%n", a, b);
			printMatrix(generateMatrix(a, b), a, b);
		}
	}

	public static void printMatrix(int[][] a, int m, int n) {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.printf("%-2d", a[i][j]);
			}
			System.out.println();
		}
	}

	public static int[][] generateMatrix(int m, int n) {
		Random r = new Random();
		int[][] a = new int[m][n];
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				a[i][j] = r.nextInt(MAXDIMENSION);
			}
		}
		return a;
	}

}
