import java.util.Scanner;

public class GPACalculate {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int credit;
        double gpa;
        int total_credit=0;
        double total_gpa=0;
        credit = in.nextInt();
        while(credit != -1){

            int score = in.nextInt();
            switch(score/10){
                case 9: case 10:
                    gpa=4.0;
                    break;
                case 8:
                    gpa=3.0;
                    break;
                case 7:
                    gpa=2.0;
                    break;
                case 6:
                    gpa=1.0;
                    break;
                default:
                    gpa=0;
            }
            total_gpa+=gpa*credit;
            total_credit+=credit;
            credit = in.nextInt();
        }

        System.out.printf("final gpa is %.1f\n",(double)total_gpa/total_credit);

    }
}
