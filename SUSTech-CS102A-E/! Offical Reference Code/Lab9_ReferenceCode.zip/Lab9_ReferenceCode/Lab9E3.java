import java.io.*;

public class Lab9E3 {
    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("src/Lab9_TestIn.txt"),"utf-8"));
            BufferedWriter writer = new BufferedWriter(new FileWriter("src/Lab9E3_TestOutput.txt"));

            String line;
            int temp;
            boolean isNeedChange;
            while ((line = in.readLine()) != null) {
                isNeedChange = true;
                for (int i = 0; i < line.length(); i++) {
                    temp = line.charAt(i);
                    if (isLowerCase(temp)) {
                        if (isNeedChange) {
                            writer.write(temp - 32);
                            isNeedChange = false;
                        } else {
                            writer.write(temp);
                        }
                    } else {
                        if (temp >= 65 && temp <= 90) {
                            isNeedChange = false;
                        } else if (temp == '.') {
                            int back = i - 1;
                            while (line.charAt(back) != ' ') {
                                back--;
                            }
                            if (isLowerCase(line.charAt(back + 1))) {
                                isNeedChange = true;
                            }
                        }
                        writer.write(temp);
                    }
                }
                writer.write('\n');
            }
            in.close();
            writer.close();
        } catch (IOException e) {
            System.out.println("There is no this file!");
        }
    }


    public static boolean isLowerCase(int temp) {
        return temp >= 97 && temp <= 122;
    }
}