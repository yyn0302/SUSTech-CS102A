
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.embed.swing.JFXPanel;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class PlayMp3 {
    public static void main(String[] args) throws FileNotFoundException, JavaLayerException {
//        final JFXPanel fxPanel = new JFXPanel();
//        File file = new File("src/a.mp3");
//        final Media media = new Media(file.toURI().toString());
//        final MediaPlayer mediaPlayer = new MediaPlayer(media);
//        mediaPlayer.setAutoPlay(true);
//        mediaPlayer.play();

        File file=new File("src/a.mp3");
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream stream = new BufferedInputStream(fis);
        Player player = new Player(stream);
        player.play();
        player.close();
    }
}

