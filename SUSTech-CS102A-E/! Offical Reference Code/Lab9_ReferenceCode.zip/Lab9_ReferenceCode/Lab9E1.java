import java.io.File;
import java.util.Formatter;


public class Lab9E1 {
     public static void main(String a[]) throws Exception
     {
        File file = new File("C:\\Users\\todd\\Desktop");
        String[] fileList = file.list();
        for(String name:fileList){
            System.out.println(name);
        }
		
    }
}