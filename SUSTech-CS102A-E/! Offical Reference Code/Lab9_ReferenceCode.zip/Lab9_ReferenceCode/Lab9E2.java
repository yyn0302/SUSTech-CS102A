import java.io.*;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;

public class Lab9E2
{
    public static void main(String[] args)
    {
        try
        {
            Scanner input = new Scanner(new File("src/Lab9_TestIn.txt"));
            Formatter output = new Formatter("src/Lab9E2_TestOutput.txt"); // open the file

            while(input.hasNext()){
                String str = input.nextLine();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < str.length(); i++) {
                    char c = str.charAt(i);
                    if (c>='a'&&c<='z'){
                        c-=('a'-'A');
                    }
                    sb.append(c);
                }
                output.format("%s\n",sb.toString());
            }
            input.close();
            output.close();
//            BufferedReader in=new BufferedReader(new FileReader("TestIn.txt"));
//            BufferedWriter writer=new BufferedWriter(new FileWriter("TestOut_EX2.txt"));
//            int temp;
//            while ((temp=in.read())!=-1)
//            {
//                if (temp>=97&&temp<=122)
//                {
//                    writer.write(temp-32);
//                }else
//                {
//                    writer.write(temp);
//                }
//            }
//            in.close();
//            writer.close();
        } catch (Exception e)
        {
            System.out.println("There is no this file!");
        }
    }
}