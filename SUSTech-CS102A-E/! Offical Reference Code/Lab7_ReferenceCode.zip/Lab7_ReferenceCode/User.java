
public class User {
	private String name;
	private String password;
	private double money;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	
	public void introduce() {
		System.out.printf("My name is %s and I have %.2f dollar\n",this.name,this.money);
	}
	
	public void expense(double money) {
		if(this.money<money) {
			System.out.println("no sufficient funds");
		}else {
			this.money-=money;
			System.out.printf("You have expense %.2f dollar and the remained amount is %.2f\n",
					money, this.money);
		}
	}
	public void income(double money) {
		this.money+=money;
		System.out.printf("The remained amount is %.2f\n",this.money);
	}
}
