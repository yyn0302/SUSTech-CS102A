

import java.util.ArrayList;

public class ClientTest {

	public static void main(String[] args) {
		User user =new User();
		user.setName("Lucy");
		user.setPassword("123456");
		user.setMoney(1000);
		user.introduce();
		user.expense(2000);
		user.expense(500);
		user.income(1000);
		user.introduce();
		
		Food pizza1=new Food();
		pizza1.setName("pizza");
		pizza1.setType("Seafood");
		pizza1.setSize(11);
		pizza1.setPrice(120);
		
		Food pizza2=new Food();
		pizza2.setName("pizza");
		pizza2.setType("Beef");
		pizza2.setSize(9);
		pizza2.setPrice(100);
		
		Food friedRice =new Food();
		friedRice.setName("fried rice");
		friedRice.setType("Seafood");
		friedRice.setSize(5);
		friedRice.setPrice(40);
		
		Food noodles =new Food();
		noodles.setName("noodles");
		noodles.setType("Beef");
		noodles.setSize(6);
		noodles.setPrice(35);
		
		ArrayList<Food> foodList=new ArrayList<>();
		foodList.add(pizza1);
		foodList.add(pizza2);
		foodList.add(friedRice);
		foodList.add(noodles);


		
		for(Food food:foodList) {
			food.showInformation();
		}
	}

}
