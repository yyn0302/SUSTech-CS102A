

public interface ColorDraw {
    public void customizedColor(ColorScheme colorScheme, int index);
}
