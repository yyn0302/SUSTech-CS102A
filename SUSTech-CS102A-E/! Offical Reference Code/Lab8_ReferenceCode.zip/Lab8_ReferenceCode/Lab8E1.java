
import java.util.Random;

public class Lab8E1 {

    public static void main(String[] args) {
        Random random = new Random();
        int n = random.nextInt(5) + 5;

        int smallestCircleIndex = 0;
        int farthestCircleIndex = 0;
        double areaMin = Double.MAX_VALUE;
        double distanceMax = Double.MIN_VALUE;

        for (int i = 0; i < n; i++) {
            double r = random.nextDouble() * 2 + 1.0;
            double x = random.nextDouble() * 3 + 2.0;
            double y = random.nextDouble() * 3 + 2.0;
            Circle c = new Circle(r, x, y);
            System.out.printf("Circle #%d: radius = %.2f, x = %.2f, y = %.2f\n", i + 1, r, x, y);
            double area = c.area();
            double distance = c.distanceToOrigin();
            if (area < areaMin) {
                areaMin = area;
                smallestCircleIndex = i + 1;
            }
            if (distance > distanceMax) {
                distanceMax = distance;
                farthestCircleIndex = i + 1;
            }
        }

        System.out.printf("Circle #%d is the smallest circle, area = %.2f\n", smallestCircleIndex, areaMin);
        System.out.printf("Circle #%d is the farthest circle, distance to origin = %.2f\n", farthestCircleIndex, distanceMax);
    }

}
